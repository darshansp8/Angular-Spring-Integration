package com.testintegration.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.testintegration.dao.TrainerDao;
import com.testintegration.model.Trainer;

@Service
public class TrainerService {
	
	@Autowired
	private TrainerDao trainerDao;

	public List<Trainer> findAllTrainers(){
		List<Trainer> trainers = new ArrayList<>();
		Iterable<Trainer> trainerList = trainerDao.findAll();
		trainerList.forEach(trainers::add);
		return trainers;
		}
	
	public List<Trainer> deleteById(int id){
		trainerDao.deleteById(id);
		List<Trainer> trainers = new ArrayList<>();
		Iterable<Trainer> trainerList = trainerDao.findAll();
		trainerList.forEach(trainers::add);
		return trainers;
		
	}

}
