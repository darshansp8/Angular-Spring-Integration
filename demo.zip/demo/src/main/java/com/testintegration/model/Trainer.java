package com.testintegration.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "trainer")
public class Trainer {
	
	@Id
	private int trainer_id;
	private String trainer_name;
	private int technology_id;
	
	
	public int getTrainer_id() {
		return trainer_id;
	}
	public void setTrainer_id(int trainer_id) {
		this.trainer_id = trainer_id;
	}
	public String getTrainer_name() {
		return trainer_name;
	}
	public void setTrainer_name(String trainer_name) {
		this.trainer_name = trainer_name;
	}
	public int getTechnology_id() {
		return technology_id;
	}
	public void setTechnology_id(int technology_id) {
		this.technology_id = technology_id;
	}
	
}
